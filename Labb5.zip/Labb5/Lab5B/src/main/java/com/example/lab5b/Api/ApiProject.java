package com.example.lab5b.Api;

import com.example.lab5b.Project.Projject;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/Api/v1/project")
public class ApiProject {

    private List<Projject> projects = new ArrayList<>();

    @GetMapping
    public List<Projject> getAllProjects()
    {
        return projects;
    }

    @PostMapping("add")
    public String addProject(@RequestBody Projject project) {
        projects.add(project);
        return ("Added");
    }
    @PutMapping("/update/{index}")
    public String updateTask(@PathVariable int index, @RequestBody Projject pro){
        projects.set(index, pro);
        return ("Updated");
    }

    @PutMapping("/{id}")
    public Projject updateProject(@PathVariable Long id, @RequestBody Projject updatedProject) {
        Projject existingProject = projects.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Project not found"));
    }


    @DeleteMapping("/{id}")
    public void deleteProject(@PathVariable Long id)
    {
        projects.removeIf(project -> project.getId().equals(id));
    }

    }

    @GetMapping("/search/{title}")
    public ArrayList<Projject> searchTaskByTitle(@PathVariable String title){
        ArrayList<Projject> result = new ArrayList<>();
        for (Projject prr : projects){
            if (prr.getTitle().equalsIgnoreCase(title)){
                result.add(prr);
            }
        }
        return result;
    }
