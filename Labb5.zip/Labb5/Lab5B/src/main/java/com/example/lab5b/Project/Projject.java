package com.example.lab5b.Project;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Projject {
    private Long id;
    private String title;
    private String description;
    private String status;
    private String companyName;

}
