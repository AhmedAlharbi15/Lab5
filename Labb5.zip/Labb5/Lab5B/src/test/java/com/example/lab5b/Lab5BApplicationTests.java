package com.example.lab5b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab5BApplicationTests {

    @Test
    void contextLoads() {
    }

}
