package com.example.lab5c;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab5cApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab5cApplication.class, args);
	}

}
