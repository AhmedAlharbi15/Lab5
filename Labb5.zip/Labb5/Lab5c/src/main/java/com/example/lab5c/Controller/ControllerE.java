package com.example.lab5c.Controller;

import com.example.lab5c.Api.Event;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;


@RestController
@RequestMapping("/event")
public class ControllerE {
    ArrayList<Event> even = new ArrayList<>();


    @GetMapping("/get")
    public ArrayList<Event> getEvent()
    {
        return even;
    }

    @PostMapping("/add")
    public String addEvent(@RequestBody Event Ev){
        even.add(Ev);
        return ("added");
    }
    @PutMapping("/update/{index}")
    public String updateEvent(@PathVariable int index, @RequestBody Event Ev){
        even.set(index, Ev);
        return ("Updated");
    }

    @DeleteMapping("/delete/{index}")
    public String deleteEvent(@PathVariable int index){
        even.remove(index);
        return ("deleted");
    }


}
