package com.example.lab5c;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab5cApplicationTests {

	@Test
	void contextLoads() {
	}

}
