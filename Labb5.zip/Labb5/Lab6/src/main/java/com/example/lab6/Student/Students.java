package com.example.lab6.Student;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Students {
    private String name;
    private int age;
    private String college;
    private double degree;
    private boolean graduated;
}
