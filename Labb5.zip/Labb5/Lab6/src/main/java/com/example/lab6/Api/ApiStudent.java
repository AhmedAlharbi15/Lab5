package com.example.lab6.Api;

import com.example.lab6.Student.Students;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1/student")
public class ApiStudent {

    public Students getStudent() {
        return new Students("Ahmed",23,"Technical College",4.04,true);
    }
    @GetMapping("/name")
    public String getName() {
        Students student = getStudent();
        return student.getName();
    }

    @GetMapping("/age")
    public int getAge() {
        Students student = getStudent();
        return student.getAge();
    }

    @GetMapping("/college/degree")
    public double getDegree() {
        Students students=getStudent();
        return students.getDegree();
    }
    @GetMapping("/study/status")
    public boolean getStudyStatus() {

        Students student = getStudent();
        return student.isGraduated();
    }

    @GetMapping("/all")
    public List<Students> getStudents() {
        List<Students> studentss = new ArrayList<>();
        return studentss;
    }
}