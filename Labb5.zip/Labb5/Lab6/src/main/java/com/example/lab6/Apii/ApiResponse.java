package com.example.lab6.Apii;

public class ApiResponse {
    private String message;
}
